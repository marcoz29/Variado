/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen_1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Marco
 */
public class Lectura {
   private ObjectInputStream lector;
    private FileInputStream archivo;
    
    public void abrir(){
        try{
            archivo = new FileInputStream("personas.bin");
            lector = new ObjectInputStream(archivo);
        }catch (FileNotFoundException e){
            System.err.println("Error al acceder al archivo");
        }catch(IOException e){
            System.err.println("Error al abrir el archivo");
        }
    }//Fin de abrir
    
    public List<Estudiante> leer(){
       Estudiante estudiante;
       List<Estudiante> lista = new ArrayList<>();
           
       boolean continuar = true;
       try{
           while(continuar){
               if(archivo.available() != 0){
                   estudiante = (Estudiante) lector.readObject();
                   lista.add(estudiante);
               }else{
                   continuar = false;
               }
           }
         }catch (IOException e){
           System.err.println("Error al abrir el archivo");
       }catch (ClassNotFoundException e){
           System.err.println("Error al leer el archivo");
       }
       
       return lista;
       
    }
               
    public void cerrar(){
        try{
            if(lector != null){
                lector.close();
            }
        }catch(IOException e){
            System.err.println("Error al cerrar el archivo");
        }
    }
}
