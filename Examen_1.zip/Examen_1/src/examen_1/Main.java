/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen_1;

import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Marco
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JOptionPane.showInputDialog("binario 1, txt 2");
        
        Estudiante estudiante1 = new Estudiante(208233456, "Luis", "Suarez", "Lopez", 6, 20, 80, 90, 82);
        
        Escritura escritura = new Escritura();
        escritura.abrir();
        escritura.escribir(estudiante1);
        escritura.cerrar();
        
        Lectura lectura = new Lectura();
        lectura.abrir();
        List<Estudiante> lista = lectura.leer();
        lectura.cerrar();
        
        for(Estudiante estudiante: lista){
            System.out.println(estudiante.toString());
        }
    }
    }
    

