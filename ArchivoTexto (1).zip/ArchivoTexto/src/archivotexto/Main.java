
package archivotexto;

import java.util.List;

/**
 *
 * @author ariel
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Escritura
//        Carro nuevoCarro = new Carro();
//        nuevoCarro.setMarca("Toyota");
//        nuevoCarro.setMotor("4AFE");
//        nuevoCarro.setAnioFabricacion(1997);
//        nuevoCarro.setModelo("Corolla");
//        nuevoCarro.setPlaca("123456");
//        nuevoCarro.setMillaje(200000);
//
//        Escritura escritura = new Escritura();
//        escritura.abrir();
//        escritura.escribir(nuevoCarro);
//        escritura.cerrar();
      
        
        
        
     //   lectura
        Lectura lectura = new Lectura();
        lectura.abrir();
        List<Carro> lista = lectura.leer();
        lectura.cerrar();
        
        for(Carro carro:lista){
            System.out.println(carro.toString());
        }
    }
    
}
