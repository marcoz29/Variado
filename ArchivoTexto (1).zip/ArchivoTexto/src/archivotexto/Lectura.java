
package archivotexto;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ariel
 */
public class Lectura {
    
    private BufferedReader lector;
    
    public void abrir(){
        try{
            lector = new BufferedReader(new FileReader("carros.txt"));
        }catch (FileNotFoundException fileNotFoundException){
            System.err.println("Error al encontrar el archivo");
        }
    }//fin del metodo abrir
    
    public List<Carro> leer(){
        Carro carro;
        List<Carro> listaCarros = new ArrayList<>();
        
        try{
            String linea = lector.readLine();
            String[] datos;
            
            while(linea != null){
                carro = new Carro();
                datos = linea.split(";");
                
                carro.setMarca(datos[0]);
                carro.setModelo(datos[1]);
                carro.setAnioFabricacion(Integer.parseInt(datos[2]));
                carro.setMotor(datos[3]);
                carro.setPlaca(datos[4]);
                carro.setMillaje(Integer.parseInt(datos[5]));
                
                listaCarros.add(carro);
                
                linea = lector.readLine();
            }//fin del while
        }catch (IOException ioException){
            System.err.println("Error al leer el archivo.");
        }
        return listaCarros;
    }//fin de la lista
    
    public void cerrar(){
        try{
            if(lector != null){
                lector.close();
            }
            
        }catch (IOException ioException){
            System.err.println("Error al cerrar el archivo");
        }
    }//fin del metodo cerrar
}//fin de la clase
