
package Archivos;

import java.util.List;
/**
 *
 * @author ariel
 */
public class Main {

    public static void main(String[] args) {

        Avion avion1 = new Avion(1, "Boeing", "747", "Comercial", "AYA", 250, 500);
       
        //escribir archivo
//        Escritura escritura = new Escritura();
//        escritura.abrir();
//        escritura.escribir(avion1);
//        escritura.cerrar();
        
        //leer archivo
        Lectura lectura = new Lectura();
        lectura.abrir();
        List<Avion> lista = lectura.leer();
        lectura.cerrar();
    
        for (Avion avion : lista){
            System.out.println(avion.toString());
        }
    }
    
}
