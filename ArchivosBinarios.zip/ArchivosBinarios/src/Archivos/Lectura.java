
package Archivos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ariel
 */
public class Lectura {
    
    private ObjectInputStream lector;
    private FileInputStream archivo;
    
    public void abrir(){
        try{
            archivo = new FileInputStream("aviones.bin");
            lector = new ObjectInputStream(archivo);
        }catch (FileNotFoundException e){
            System.err.println("Error al acceder al archivo");
        }catch (IOException e){
            System.err.println("Error al abrir el archivo");
        }
        
        }//fin del metodo abrir
    
    public List<Avion> leer(){
        Avion avion;
        List<Avion> lista = new ArrayList<>();
    
        boolean continuar = true;
        try{
            while(continuar){
                if(archivo.available() != 0){
                    avion = (Avion) lector.readObject();
                    lista.add(avion);
                }else {
                    continuar = false;
                }
            }
        }catch (IOException e){
            System.err.println("Error al abrir el archivo");
        }catch (ClassNotFoundException e){
            System.err.println("Error al leer el archivo");
        }
        return lista;
    }//fin de la lista
    
    public void cerrar(){
        try{
            if(lector != null){
                lector.close();
            }
        }catch (IOException e){
            System.err.println("Error al cerrar el archivo");
        }
    }//fin del metodo cerrar
  }//fin de la clase

