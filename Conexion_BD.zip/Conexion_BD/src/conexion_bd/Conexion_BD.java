/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conexion_bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Marco
 */
public class Conexion_BD {


    public static void main(String[] args) {
       
        String usuario = "root";
        String clave = "mvrm1998";
        String url = "jdbc:mysql://localhost:3306/Investigacion_BD";
        Connection con;
        Statement stmt;
        ResultSet rs;
         
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion_BD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            con = DriverManager.getConnection(url,usuario,clave);
            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO Persona VALUES(1,'Juan','Carazo', 'Rodriguez', 'Alajuela', 22440000)");
            rs = stmt.executeQuery("SELECT * FROM Persona");
            rs.next();
            System.out.println("Conectado a la Base de Datos");
            do{
                System.out.println("Resultado de la consulta:");
                System.out.println("ID: "+rs.getString("id")+" Nombre: "+rs.getString("nombre")+" PrimerApellido: "+rs.getString("primer_apellido")+" SegundoApellido: "+rs.getString("segundo_apellido")+" Provincia: "+rs.getString("provincia")+" Telefono: "+rs.getString("telefono"));
            }while(rs.next());
        } catch (SQLException ex) {
            Logger.getLogger(Conexion_BD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
