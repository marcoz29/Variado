
package archivotexto;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author ariel
 */
public class Escritura {
    
    private BufferedWriter escritor;
    
    public void abrir(){
        try{
            escritor = new BufferedWriter(new FileWriter("carros.txt", true));
        }catch (IOException ioException){
            System.err.println("Error al crear el archivo");
        }//fin catch
    }//fin del metodo abrir
    
    public void escribir(Carro carro){
        try{
            escritor.write(carro.guardar());
            
        }catch (IOException ioException){
            System.err.println("Error al escribir en el archivo");
        }
    }//fin del metodo escribir
    
     public void cerrar(){
        try{
            if(escritor != null){
                escritor.close();
            }
            
        }catch (IOException ioException){
            System.err.println("Error al cerrar el archivo");
        }
    }//fin del metodo cerrar
}
