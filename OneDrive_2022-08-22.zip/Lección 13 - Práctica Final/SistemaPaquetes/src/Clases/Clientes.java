
package Clases;

import static Datos.BD.tbl_Clientes;
import java.util.ArrayList;

/**
 *
 * @author ariel
 */
public class Clientes {
    
    private int Id_Cliente;
    private String Cedula;
    private String Nombre;
    private String Apellidos;
    private int Telefono;
    private String Correo;

    
    public Clientes() {
        //Crea una instancia plana y vacía del objeto.
    }

    //creación del objeto con un valor inicial para un atributo
    public Clientes(int Id_Cliente) {
        this.Id_Cliente = Id_Cliente;
    }
    
    //constructor
    public Clientes(int Id_Cliente, String Cedula, String Nombre, String Apellidos, int Telefono, String Correo) {
        this.Id_Cliente = Id_Cliente;
        this.Cedula = Cedula;
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Telefono = Telefono;
        this.Correo = Correo;
    }

    
    //metodos get y set
    public int getId_Cliente() {
        return Id_Cliente;
    }

    public void setId_Cliente(int Id_Cliente) {
        this.Id_Cliente = Id_Cliente;
    }

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String Cedula) {
        this.Cedula = Cedula;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    public String getApellidos(){
        return Apellidos;
    }
    
    public void setApellidos(String Apellidos){
        this.Apellidos = Apellidos;
    }

    public int getTelefono() {
        return Telefono;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }
    
    
    
    //permite listar los clientes en el sistema
    public ArrayList<Clientes> Listar(){
        return tbl_Clientes;
    }
    
    
    public boolean Guardar()
    {
        this.setId_Cliente(tbl_Clientes.size() + 1); //incrementa el id
        boolean Guardado = tbl_Clientes.add(this); //se crea una variable boolean llamada Guardado
        //donde sea true vaya a guardar.
        return Guardado;
    }//fin del metodo guardar
    
    public boolean Modificar()
    {
        boolean Modificar = false; //se crea la variable modificar, sino es false va a realizar el proceso siguiente
        for(Clientes Fila : tbl_Clientes)//la clase cliente contiene un objeto llamado fila que esta contenido en la tbl_Clientes
        {
            if(Fila.getId_Cliente() == this.Id_Cliente){ //si la Fila.getId_Cliente es igual a id_Cliente ingresado, entonces...
                Fila.setNombre(getNombre());
                Fila.setApellidos(getApellidos());
                Fila.setCedula(getCedula());
                Fila.setCorreo(getCorreo());
                Fila.setTelefono(getTelefono());
                Modificar = true;
                break;
                
            }
        }
        return Modificar;
    }//fin del metodo modificar
    
    public Clientes Consultar() {
        Clientes Consultado = null;
        for(Clientes Fila : tbl_Clientes){
            if(Fila.getId_Cliente() == this.getId_Cliente()){
                Consultado = Fila;
                break;
            }
        }
        return Consultado;
    }//fin del metodo consultar
    
}
