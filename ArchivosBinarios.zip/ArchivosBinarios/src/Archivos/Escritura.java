
package Archivos;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 *
 * @author ariel
 */
public class Escritura {

    private ObjectOutputStream escritor;
    
    public void abrir(){
        
        try{
            escritor = new ObjectOutputStream(new FileOutputStream("aviones.bin"));
        }catch (FileNotFoundException e){
            System.err.println("Error al acceder al archivo");
        }catch (IOException e){
            System.err.println("Error al abrir el archivo");
        }
    }//fin del metodo abrir
    
    public void escribir(Avion avion){
        try{
            escritor.writeObject(avion);
        }catch (IOException e){
            System.err.println("Error al escribir en el archivo");
        }
    }//fin del metodo escribir
    
    public void cerrar(){
        try{
            if(escritor != null){
                escritor.close();
            }
        }catch (IOException e){
            System.err.println("Error al cerrar el archivo");
        }
    }//fin del metodo cerrar
    
}//fin de la clase escritura
