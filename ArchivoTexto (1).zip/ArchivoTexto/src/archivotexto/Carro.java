
package archivotexto;

/**
 *
 * @author ariel
 */
public class Carro {
    
    //variables
    private String marca;
    private String modelo;
    private int anioFabricacion;
    private String motor;
    private String placa;
    private int millaje;
    
    public Carro(){
        this("","",0,"","",0);
    }

    public Carro(String marca, String modelo, int anioFabricacion, String motor, String placa, int millaje) {
        this.marca = marca;
        this.modelo = modelo;
        this.anioFabricacion = anioFabricacion;
        this.motor = motor;
        this.placa = placa;
        this.millaje = millaje;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public void setAnioFabricacion(int anioFabricacion) {
        this.anioFabricacion = anioFabricacion;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getMillaje() {
        return millaje;
    }

    public void setMillaje(int millaje) {
        this.millaje = millaje;
    }

    public String guardar(){
        return marca + ";"+
                modelo + ";" +
                anioFabricacion + ";" +
                motor + ";" +
                placa + ";" +
                millaje + "\n";
    }
    
    @Override
    public String toString(){
        return "Carro" + "\n" +
                "Marca:" + marca + "\n" +
                "Modelo:" + modelo + "\n" +
                "Año de fabricación:" + anioFabricacion + "\n" +
                "Motor:" + motor + "\n" +
                "Placa:" + placa + "\n" +
                "Millaje:" + millaje + "\n";
    }//fin del metodo toString
    
}//fin de la clase

