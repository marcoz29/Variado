
package com.progra1.estudiantenota;

/**
 *
 * @author ariel
 */
public class EstudianteNota {
    
	public static void main(String arg[])
	{
		//OperacionesEN registro = new OperacionesEN();
		//registro.menu();
	}
}

