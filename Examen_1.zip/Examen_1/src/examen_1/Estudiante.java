/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen_1;

import java.io.Serializable;
/**
 *
 * @author Marco
 */
public class Estudiante implements Serializable{
    private int cedula;
    private String nombre;
    private String primerApellido;
    private String segundoApellido;
    private int grado;
    private int primerExamen;
    private int segundoExamen;
    private int tercerExamen;
    private int promedioFinal;

    public Estudiante() {
        this(0, "", "", "", 0, 0, 0, 0, 0);
    }
    
    public Estudiante(int cedula, String nombre, String primerApellido, String segundoApellido, int grado, int primerExamen, int segundoExamen, int tercerExamen, int promedioFinal){
        this.cedula = cedula;
        this.nombre = nombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.grado = grado;
        this.primerExamen = primerExamen;
        this.segundoExamen = segundoExamen;
        this.tercerExamen = tercerExamen;
        this.promedioFinal = promedioFinal;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public String getSegundoApellido() {
        return segundoApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }

    public int getGrado() {
        return grado;
    }

    public void setGrado(int grado) {
        this.grado = grado;
    }

    public int getPrimerExamen() {
        return primerExamen;
    }

    public void setPrimerExamen(int primerExamen) {
        this.primerExamen = primerExamen;
    }

    public int getSegundoExamen() {
        return segundoExamen;
    }

    public void setSegundoExamen(int segundoExamen) {
        this.segundoExamen = segundoExamen;
    }

    public int getTercerExamen() {
        return tercerExamen;
    }

    public void setTercerExamen(int tercerExamen) {
        this.tercerExamen = tercerExamen;
    }

    public int getPromedioFinal() {
        return promedioFinal;
    }

    public void setPromedioFinal(int promedioFinal) {
        this.promedioFinal = promedioFinal;
    }
    
    @Override
    public String toString(){
        return "Notas \n" +
                "Cedula: " + cedula + "\n" +
                "Nombre: " + nombre + "\n" +
                "Primer Apellido: " + primerApellido + "\n" +
                "Segundo Apellido: " + segundoApellido + "\n" +
                "Grado: " + grado + "\n" +
                "Primer examen: " + primerExamen + "\n" +
                "Segundo examen: " + segundoExamen + "\n" +
                "Tercer examen: " + tercerExamen + "\n" +
                "Promedio Final: " + promedioFinal + "\n";
    }
    
}
