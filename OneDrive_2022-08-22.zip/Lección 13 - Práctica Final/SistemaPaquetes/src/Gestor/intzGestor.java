/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Gestor;

import Clases.Clientes;
import Clases.Conductor;
import java.util.ArrayList;

/**
 *
 * @author ariel
 */
public interface intzGestor {
    
    //clientes
    public boolean GuardarClientes(Clientes myCliente);
    public boolean ModificarCliente(Clientes myCliente);
    public Clientes ConsultarClientes(int Id);
    public ArrayList<Clientes> ListarClientes();
    
    //conductor
    public boolean GuardarConductor(Conductor myConductor);
    public boolean ModificarConductor(Conductor myConductor);
    public Conductor ConsultarConductor(int id);
    public ArrayList<Conductor> ListarConductor();
}
