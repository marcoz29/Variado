
package Clases;

import Datos.BD;
import static Datos.BD.tbl_Conductor;
import java.util.ArrayList;


/**
 *
 * @author User
 */
public class Conductor {
    //variables
    private int Id_Conductor;
    private String Cedula;
    private String Nombre;
    private String Apellidos;
    private String Telefono;
    private String Licencia;

    public Conductor() {
    }

    public Conductor(int Id_Conductor, String Cedula, String Nombre, String Apellidos, String Telefono, String Licencia) {
        this.Id_Conductor = Id_Conductor;
        this.Cedula = Cedula;
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Telefono = Telefono;
        this.Licencia = Licencia;
    }

    public Conductor(int Id_Conductor) {
        this.Id_Conductor = Id_Conductor;
    }

    public int getId_Conductor() {
        return Id_Conductor;
    }

    public void setId_Conductor(int Id_Conductor) {
        this.Id_Conductor = Id_Conductor;
    }

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String Cedula) {
        this.Cedula = Cedula;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getLicencia() {
        return Licencia;
    }

    public void setLicencia(String Licencia) {
        this.Licencia = Licencia;
    }
    
    public boolean Guardar()
    {
        this.setId_Conductor(BD.tbl_Conductor.size()+1);
        boolean Guardado = tbl_Conductor.add(this); //se crea una variable boolean llamada Guardado
        //donde sea true vaya a guardar.
        return Guardado;
    }
    
    public boolean Modificar(){
        boolean Modificado = false;
        for(Conductor Fila : BD.tbl_Conductor){
        if(Fila.getId_Conductor() == this.getId_Conductor()){
            Fila.setNombre(getNombre());
            Fila.setApellidos(getApellidos());
            Fila.setCedula(getCedula());
            Fila.setTelefono(getTelefono());
            Fila.setLicencia(getLicencia());
            Modificado = true;
            break;
            }
        }
        return Modificado;
    
    }
    
    public Conductor Consultar(){
        Conductor Consultado = null;
        for (Conductor Fila : BD.tbl_Conductor) {
            if (Fila.getId_Conductor() == this.getId_Conductor()) {
                Consultado = Fila;
                break;
            }
        }
        return Consultado;
    }
    
    public ArrayList<Conductor> Listar(){
        return BD.tbl_Conductor;
    }
    
}
