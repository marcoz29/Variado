/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen_1;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
/**
 *
 * @author Marco
 */
public class Escritura {
    private ObjectOutputStream escritor;
    
    public void abrir(){
        try{
            escritor = new ObjectOutputStream(new FileOutputStream("personas.bin"));
        
        }catch(FileNotFoundException e){
            System.err.println("Error al acceder al archivo");
        }catch(IOException e){
            System.err.println("Error al abrir el archivo");
        }
    }//Fin de abrir
    
    public void escribir(Estudiante estudiante){
        try{
            escritor.writeObject(estudiante);
        }catch (IOException e){
            System.err.println("Error al escribir el archivo");
        }
    }//Fin de escribir
    
    public void cerrar(){
        try{
            if(escritor != null){
                escritor.close();
            }
        }catch(IOException e){
            System.err.println("Error al cerrar el archivo");
        }
    }//Fin de cerrar
    
}
