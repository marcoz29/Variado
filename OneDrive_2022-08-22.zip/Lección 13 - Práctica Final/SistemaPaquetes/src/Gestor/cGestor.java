/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestor;

import Clases.Clientes;
import Clases.Conductor;
import java.util.ArrayList;
/**
 *
 * @author ariel
 */
public class cGestor implements intzGestor{

    @Override
    public boolean GuardarClientes(Clientes myCliente) {
        try{
            if(myCliente.Consultar()==null){
                return myCliente.Guardar();
            }
        } catch (Exception ex)
        {
            String error = ex.getMessage();
        }
        return false;
    }

    @Override
    public boolean ModificarCliente(Clientes myClientes) {
        try{
            if(myClientes.Consultar()!=null){
                return myClientes.Modificar();
            }
        } catch (Exception ex){
            String error = ex.getMessage();
        }
        return false;
    }
    

    @Override
    public Clientes ConsultarClientes(int Id) {
        try{
            return new Clientes(Id).Consultar();
            
        } catch (Exception ex){
            String error = ex.getMessage();
            return null;
        }
        
    }

    @Override
    public ArrayList<Clientes> ListarClientes() {
        try{
            return new Clientes().Listar();
            
        } catch (Exception ex){
            String error = ex.getMessage();
            return null;
        }
       }

    
    //Conductor
    @Override
    public boolean GuardarConductor(Conductor myConductor) {
        try{
            if (myConductor.Consultar()== null)
            {
                return myConductor.Guardar();
            }
        } catch (Exception ex)
        {
            String error = ex.getMessage();
            
        }return false;
    }

    @Override
    public boolean ModificarConductor(Conductor myConductor) {
        try{
            if (myConductor.Consultar()!= null)
            {
                return myConductor.Modificar();
            }
        } catch (Exception ex)
        {
            String error = ex.getMessage();
            
        }return false;
    }

    @Override
    public Conductor ConsultarConductor(int id) {
        try {
            return new Conductor(id).Consultar();
        } catch (Exception ex) {
            String error = ex.getMessage();
        }
        return null;
    }

    @Override
    public ArrayList<Conductor> ListarConductor() {
       try{
                return new Conductor().Listar();
            
        } catch (Exception ex)
        {
            String error = ex.getMessage();
            
        }return null;
    }
    }
    
 