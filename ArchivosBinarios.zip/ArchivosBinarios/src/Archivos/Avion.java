package Archivos;

import java.io.Serializable;

public class Avion implements Serializable {
    private int id;
    private String fabricante;
    private String modelo;
    private String tipo;
    private String aerolinea;
    private int cantidadPasajeros;
    private int cantidadEquipaje;

    public Avion() {
        this(0, "", "", "", "", 0, 0);
    }

    public Avion(int id, String fabricante, String modelo, String tipo, String aerolinea, int cantidadPasajeros, int cantidadEquipaje) {
        this.id = id;
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.tipo = tipo;
        this.aerolinea = aerolinea;
        this.cantidadPasajeros = cantidadPasajeros;
        this.cantidadEquipaje = cantidadEquipaje;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getAerolinea() {
        return aerolinea;
    }

    public void setAerolinea(String aerolinea) {
        this.aerolinea = aerolinea;
    }

    public int getCantidadPasajeros() {
        return cantidadPasajeros;
    }

    public void setCantidadPasajeros(int cantidadPasajeros) {
        this.cantidadPasajeros = cantidadPasajeros;
    }

    public int getCantidadEquipaje() {
        return cantidadEquipaje;
    }

    public void setCantidadEquipaje(int cantidadEquipaje) {
        this.cantidadEquipaje = cantidadEquipaje;
    }

    @Override
    public String toString() {
        return "Avion \n" +
                "ID: " + id + "\n" +
                "Fabricante: " + fabricante + "\n" +
                "Modelo: " + modelo + "\n" +
                "Tipo: " + tipo + "\n" +
                "Aerolinea: " + aerolinea + "\n" +
                "Cantidad Pasajeros: " + cantidadPasajeros  + "\n" +
                "Cantidad Equipaje: " + cantidadEquipaje  + "\n";
    }
}
